
package telas;

import Conect.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class Tela_Menu extends javax.swing.JFrame {
        private int id_usuario;
        ArrayList<String> eventoCompromisso = new ArrayList<String>();
    
    public Tela_Menu() {
    initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jCalendar1 = new com.toedter.calendar.JCalendar();
        jScrollPane1 = new javax.swing.JScrollPane();
        ListaCompromisso = new javax.swing.JTable();
        comp = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        Login = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        Add_cliente = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        Add_Compromisso = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        Edit_Perfil = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        ListaCompromisso.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id_Usuario", "Id_Compromisso", "Titulo", "Dt_inic", "Dt_fim", "local"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(ListaCompromisso);
        if (ListaCompromisso.getColumnModel().getColumnCount() > 0) {
            ListaCompromisso.getColumnModel().getColumn(0).setResizable(false);
            ListaCompromisso.getColumnModel().getColumn(1).setResizable(false);
            ListaCompromisso.getColumnModel().getColumn(2).setResizable(false);
            ListaCompromisso.getColumnModel().getColumn(3).setResizable(false);
            ListaCompromisso.getColumnModel().getColumn(4).setResizable(false);
            ListaCompromisso.getColumnModel().getColumn(5).setResizable(false);
        }

        comp.setText("Chamar compromissos");
        comp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                compActionPerformed(evt);
            }
        });

        jMenu1.setText("Menu");
        jMenu1.setMinimumSize(new java.awt.Dimension(50, 50));
        jMenu1.setPreferredSize(new java.awt.Dimension(60, 30));

        Login.setText("Login");
        Login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LoginActionPerformed(evt);
            }
        });
        jMenu1.add(Login);

        jMenuBar1.add(jMenu1);

        jMenu2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/contatos.png"))); // NOI18N
        jMenu2.setText("Contatos");
        jMenu2.setMinimumSize(new java.awt.Dimension(30, 30));
        jMenu2.setPreferredSize(new java.awt.Dimension(80, 30));

        Add_cliente.setText("Cadastrar/Excluir ");
        Add_cliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Add_clienteActionPerformed(evt);
            }
        });
        jMenu2.add(Add_cliente);

        jMenuBar1.add(jMenu2);

        jMenu3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/comprimisso .png"))); // NOI18N
        jMenu3.setText("Compromissos");
        jMenu3.setPreferredSize(new java.awt.Dimension(110, 30));

        Add_Compromisso.setText("Adicionar novo");
        Add_Compromisso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Add_CompromissoActionPerformed(evt);
            }
        });
        jMenu3.add(Add_Compromisso);

        jMenuBar1.add(jMenu3);

        jMenu4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/perfil.png"))); // NOI18N
        jMenu4.setText("Perfil");
        jMenu4.setPreferredSize(new java.awt.Dimension(60, 30));

        Edit_Perfil.setText("Editar /Visualizar");
        Edit_Perfil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Edit_PerfilActionPerformed(evt);
            }
        });
        jMenu4.add(Edit_Perfil);

        jMenuBar1.add(jMenu4);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jCalendar1, javax.swing.GroupLayout.PREFERRED_SIZE, 443, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(layout.createSequentialGroup()
                .addGap(140, 140, 140)
                .addComponent(comp))
            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 443, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jCalendar1, javax.swing.GroupLayout.PREFERRED_SIZE, 319, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(comp)
                .addGap(17, 17, 17)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 439, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void LoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LoginActionPerformed

        Tela_Logar telalog = new Tela_Logar();
        telalog.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        telalog.setVisible(true);
        
        
    }//GEN-LAST:event_LoginActionPerformed
    public void setUsuarioLogado(int id_usuario){
        this.id_usuario = id_usuario;
        System.out.println("Logou\n "+id_usuario);
    }
            
    private void Add_clienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Add_clienteActionPerformed
        
        TelaCdContato telacon = new TelaCdContato();
        telacon.setUsuarioLogado(this.id_usuario);
        telacon.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        telacon.ListaCd();
        telacon.setVisible(true);
         
    }//GEN-LAST:event_Add_clienteActionPerformed

    private void Add_CompromissoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Add_CompromissoActionPerformed
        
        TelaCdCompromisso cdcomp = new TelaCdCompromisso();
        cdcomp.setUsuarioLogado(this.id_usuario);
        cdcomp.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        cdcomp.fillContacts();
        cdcomp.setVisible(true);
    }//GEN-LAST:event_Add_CompromissoActionPerformed
  
    private void Edit_PerfilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Edit_PerfilActionPerformed
        
        TelaInfosUsuario UserInfos = new TelaInfosUsuario();
        UserInfos.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        UserInfos.setVisible(true);
    }//GEN-LAST:event_Edit_PerfilActionPerformed

    private void compActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_compActionPerformed
                                                   
    }//GEN-LAST:event_compActionPerformed
        
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Tela_Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Tela_Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Tela_Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Tela_Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Tela_Menu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem Add_Compromisso;
    private javax.swing.JMenuItem Add_cliente;
    private javax.swing.JMenuItem Edit_Perfil;
    private javax.swing.JTable ListaCompromisso;
    private javax.swing.JMenuItem Login;
    private javax.swing.JButton comp;
    private com.toedter.calendar.JCalendar jCalendar1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
