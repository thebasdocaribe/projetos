package telas;

import java.sql.SQLException;

public class Main {
    public static void main(String[] args) throws SQLException {
        Tela_Logar log = new Tela_Logar();
        log.setVisible(true);
}
}