
package telas;

import Conect.ConnectionFactory;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.ResultSet ;
import java.sql.PreparedStatement;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class TelaCdContato extends javax.swing.JFrame {
        private int id_usuario;
        
        
        
        public TelaCdContato() {
        initComponents();
    }
 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        CampoTelCon = new javax.swing.JFormattedTextField();
        jLabel6 = new javax.swing.JLabel();
        CampoNomeCon = new javax.swing.JTextField();
        CampoEmailCon = new javax.swing.JTextField();
        Foto = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        CampoDt_nasc = new javax.swing.JFormattedTextField();
        jLabel2 = new javax.swing.JLabel();
        Confirmar = new javax.swing.JButton();
        Excluir = new javax.swing.JButton();
        CampoRua = new javax.swing.JTextField();
        CampoNumero = new javax.swing.JTextField();
        CampoBairro = new javax.swing.JTextField();
        CampoCidade = new javax.swing.JTextField();
        CampoCPF = new javax.swing.JFormattedTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        TabelaContatos = new javax.swing.JTable();
        CampoEstado = new javax.swing.JFormattedTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jLabel3.setText("Dt_Nascimento");

        jLabel4.setText("E-mail");

        try {
            CampoTelCon.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("(##)####-#####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        jLabel6.setText("Telefone");

        Foto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/teste.png"))); // NOI18N

        jLabel1.setText("Nome");

        try {
            CampoDt_nasc.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("####-##-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        jLabel2.setText("CPF");

        Confirmar.setText("Confirmar");
        Confirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConfirmarActionPerformed(evt);
            }
        });

        Excluir.setText("Excluir");
        Excluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExcluirActionPerformed(evt);
            }
        });

        try {
            CampoCPF.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###.###.###-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        jLabel7.setText("Rua");

        jLabel8.setText("Numero");

        jLabel9.setText("Bairro");

        jLabel10.setText("Cidade");

        jLabel11.setText("Estado");

        TabelaContatos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "id_contato", "CPF", "Nome", "Dt_nascimento", "Telefone", "E_mail", "Rua", "Numero", "Bairro", "Cidade", "Estado"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(TabelaContatos);
        if (TabelaContatos.getColumnModel().getColumnCount() > 0) {
            TabelaContatos.getColumnModel().getColumn(0).setResizable(false);
            TabelaContatos.getColumnModel().getColumn(1).setResizable(false);
            TabelaContatos.getColumnModel().getColumn(2).setResizable(false);
            TabelaContatos.getColumnModel().getColumn(3).setResizable(false);
            TabelaContatos.getColumnModel().getColumn(4).setResizable(false);
            TabelaContatos.getColumnModel().getColumn(5).setResizable(false);
            TabelaContatos.getColumnModel().getColumn(6).setResizable(false);
            TabelaContatos.getColumnModel().getColumn(7).setResizable(false);
            TabelaContatos.getColumnModel().getColumn(8).setResizable(false);
            TabelaContatos.getColumnModel().getColumn(9).setResizable(false);
            TabelaContatos.getColumnModel().getColumn(10).setResizable(false);
        }

        try {
            CampoEstado.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addComponent(jLabel7)
                        .addGap(96, 96, 96)
                        .addComponent(jLabel8)
                        .addGap(86, 86, 86)
                        .addComponent(jLabel9))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(CampoNomeCon)
                            .addComponent(CampoEmailCon)
                            .addComponent(CampoDt_nasc)
                            .addComponent(CampoTelCon)
                            .addComponent(CampoCPF)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(jLabel6))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(CampoRua, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(CampoCidade, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(16, 16, 16)
                                                .addComponent(Excluir))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(36, 36, 36)
                                                .addComponent(jLabel10)))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(6, 6, 6)
                                                .addComponent(CampoNumero, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(CampoBairro, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(Foto)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addGap(18, 18, 18)
                                                        .addComponent(CampoEstado, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addGap(41, 41, 41)
                                                        .addComponent(Confirmar))
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addGap(63, 63, 63)
                                                        .addComponent(jLabel11)))))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 91, Short.MAX_VALUE)))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 381, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(3, 3, 3)
                        .addComponent(CampoNomeCon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(CampoCPF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3)
                        .addGap(12, 12, 12)
                        .addComponent(CampoDt_nasc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(CampoEmailCon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(3, 3, 3)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(CampoTelCon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8)
                            .addComponent(jLabel9))
                        .addGap(7, 7, 7)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(CampoRua, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(CampoNumero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(CampoBairro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(Foto))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2)
                        .addGap(14, 14, 14))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(CampoEstado, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(Confirmar)
                        .addGap(13, 13, 13))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(418, 418, 418)
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(CampoCidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(Excluir)
                        .addGap(0, 13, Short.MAX_VALUE)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConfirmarActionPerformed
            
        System.out.println("Clicou");
        Connection con;
        String query = "insert into Contatos values ("+
                this.id_usuario+
                ", null, \"" +
                this.CampoCPF.getText() +
                "\", \"" +
                this.CampoNomeCon.getText() +
                "\", \"" +
                this.CampoDt_nasc.getText()+
                "\", \"" +
                this.CampoTelCon.getText().replaceAll("[()-]","")+
                "\", \"" +
                this.CampoEmailCon.getText()+
                "\", \"" +
                this.CampoRua.getText()+
                "\", \"" +
                this.CampoNumero.getText()+
                "\", \"" +
                this.CampoBairro.getText()+
                "\", \"" +
                this.CampoCidade.getText()+
                "\", \"" +
                this.CampoEstado.getText()+                            
                "\")"; 
                
        try {
            System.out.println("query executada\n"+query);
            
            con = ConnectionFactory.getConnection();
            
            Statement stn = con.createStatement();
            stn.executeUpdate(query);

            System.out.println("Tentou executar:\n" + query);
            con.close();

        } catch (SQLException ex) {
            System.out.println("Fudeu"+ex.getMessage());
            JOptionPane.showMessageDialog(null, ex.getMessage());
           
        }
        ListaCd();             
    }//GEN-LAST:event_ConfirmarActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        this.setVisible(false);
        
    }//GEN-LAST:event_formWindowClosing

    private void ExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExcluirActionPerformed
            
    }//GEN-LAST:event_ExcluirActionPerformed
         
      public void ListaCd(){
        try{ 
            Connection con;
            ResultSet conts;
            PreparedStatement ps;
            con = ConnectionFactory.getConnection();            
            String query = "select * from contatos where Id_Usuario = " + this.id_usuario;           
            ps = con.prepareStatement(query);
            conts = ps.executeQuery();
            if(conts.next()){
                DefaultTableModel tabela = (DefaultTableModel) this.TabelaContatos.getModel();
                Object data[] = new Object[11];
                tabela.setRowCount(0);
                data[0] = conts.getString("id_contato");
                data[1] = conts.getString("CPF");
                data[2] = conts.getString("Nome");
                data[3] = conts.getString("Dt_Nascimento");
                data[4] = conts.getString("Telefone");
                data[5] = conts.getString("E_mail");
                data[6] = conts.getString("Rua");
                data[7] = conts.getString("Numero");
                data[8] = conts.getString("Bairro");
                data[1] = conts.getString("Cidade");
                data[10] = conts.getString("Estado");
                tabela.addRow(data);
                while(conts.next()){
                    data[0] = conts.getString("id_contato");
                    data[1] = conts.getString("CPF");
                    data[2] = conts.getString("Nome");
                    data[3] = conts.getString("Dt_Nascimento");
                    data[4] = conts.getString("Telefone");
                    data[5] = conts.getString("E_mail");
                    data[6] = conts.getString("Rua");
                    data[7] = conts.getString("Numero");
                    data[8] = conts.getString("Bairro");
                    data[9] = conts.getString("Cidade");
                    data[10] = conts.getString("Estado");
                    tabela.addRow(data);
                }
                tabela.fireTableDataChanged();
            } else {
                DefaultTableModel tabela = (DefaultTableModel) this.TabelaContatos.getModel();
                tabela.setRowCount(0);
                tabela.fireTableDataChanged();
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao buscar dados de grupos !", "Erro ao conectar", 0);
        }
    }
    public void setUsuarioLogado(int id_usuario){
         this.id_usuario = id_usuario;        
    }
    public static void main(String args[]) {
        
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaCdContato.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaCdContato.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaCdContato.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaCdContato.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaCdContato().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField CampoBairro;
    private javax.swing.JFormattedTextField CampoCPF;
    private javax.swing.JTextField CampoCidade;
    private javax.swing.JFormattedTextField CampoDt_nasc;
    private javax.swing.JTextField CampoEmailCon;
    private javax.swing.JFormattedTextField CampoEstado;
    private javax.swing.JTextField CampoNomeCon;
    private javax.swing.JTextField CampoNumero;
    private javax.swing.JTextField CampoRua;
    private javax.swing.JFormattedTextField CampoTelCon;
    private javax.swing.JButton Confirmar;
    private javax.swing.JButton Excluir;
    private javax.swing.JLabel Foto;
    private javax.swing.JTable TabelaContatos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
