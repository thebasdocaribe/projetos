
package Classes;


public class UsuarioInfos {
    
    public String Login;
    public String Senha;
 
    
    public UsuarioInfos(String Login, String Senha){
        this.Login = Login;
        this.Senha = Senha;
    }
    
    public String getLogin(){
        return Login;
    }
    
    public void setLogin(String Login){
        this.Login = Login;
    }

    public String getSenha(){
        return Senha;
    }
    
    public void setSenha(String Senha){
        this.Senha = Senha;
    }

    public void setDescricao(String string) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setId(int aInt) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}


