
package Classes;

import java.util.Date;


public class Contatos {
    

    static String getFoto() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static String getEndereco() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static int getId() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    public String Nome;
    public static String CPF;
    public Date Dt_Nascimento; 
    public int Telefone;
    public String Email;
   
    
    public Contatos(){
        
}
    
    public Contatos(String Nome, String CPF, Date Dt_Nascimento, int Telefone, String Email, int Numero, String Rua,
            String Bairro, String Cidade){
        this.Nome = Nome;
        this.CPF = CPF;
        this.Dt_Nascimento = Dt_Nascimento;
        this.Telefone = Telefone;
        this.Email = Email;
        
    }
    
    public String getNome(){
        return Nome;
    }
    
    public void setNome(String Nome){
        this.Nome = Nome;
    }
    
    public static String getCPF(){
        return CPF;      
    }
    
    public void setCPF(String CPF){
        this.CPF = CPF;
    }
    
    public Date getDt_Nascimento(){
        return Dt_Nascimento;
    }
    
    public void setDt_Nascimento(Date Dt_Nascimento){
        this.Dt_Nascimento = Dt_Nascimento;
    }
    
    public int getTelefone(){
        return Telefone;
    } 
    
    public void setTelefone(int Telefone){
        this.Telefone = Telefone;
    }
    
    public String getEmail(){
        return Email;
    }
    
    public void setTelefone(String Email){
        this.Email = Email;
    }

    }